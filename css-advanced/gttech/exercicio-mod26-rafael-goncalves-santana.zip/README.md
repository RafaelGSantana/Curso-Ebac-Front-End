## Instalação
- Requer o node.js instalado
- Baixar ou clonar este repositório
- Acessar com o terminal a pasta do projeto, baixado e **executar o comando**:
```
npm install 
```
## Execução
- Na raiz do projeto, executar o comando:
```
npm run dev
```